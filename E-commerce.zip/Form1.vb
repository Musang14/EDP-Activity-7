﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If txtUsername.Text = "pj123" And txtPassword.Text = "123" Then
            MsgBox("Login Successfully!")
            txtUsername.Text = ""
            txtPassword.Text = ""
            Form2.Show()
            Me.Hide()
        Else
            MsgBox("Invalid Username or Password")
            txtUsername.Text = ""
            txtPassword.Text = ""
        End If
    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub
End Class
